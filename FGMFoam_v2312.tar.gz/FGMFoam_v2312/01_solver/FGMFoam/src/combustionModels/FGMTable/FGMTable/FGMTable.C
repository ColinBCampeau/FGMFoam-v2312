/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2009-2009 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

\*---------------------------------------------------------------------------*/


#include "FGMTable.H"
#include <stdio.h>

namespace Foam
{

defineTypeNameAndDebug(FGMTable, 0);
defineRunTimeSelectionTable(FGMTable, dictionary);

// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

FGMTable::FGMTable
(
 const fvMesh& mesh,
 const word& tablePath,
 const word& tableName
)
:
   IOdictionary
   (
      IOobject
      (
         tableName,
         tablePath,
         mesh,
         IOobject::READ_IF_PRESENT,
         IOobject::NO_WRITE
      )
   ),
   tableName_(tableName)
{}

// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

FGMTable::~FGMTable()
{}

// * * * * * * * * * * * * * * * * Selectors * * * * * * * * * * * * * * * * //

Foam::autoPtr<Foam::FGMTable> Foam::FGMTable::New
(
  const fvMesh& mesh,
  const word& tablePath,
  const word& tableName
)
{
    const word modelName
    (
        IOdictionary
        (
            IOobject
            (
                "tableProperties",
                mesh.time().constant(),
                mesh,
                IOobject::MUST_READ,
                IOobject::NO_WRITE,
                false
            )
        ).lookup("interpolationType")
    );


Info << "Entering FGMTable" << endl;


//    dictionaryConstructorTable::iterator cstrIter =
//    dictionaryConstructorTablePtr_->find(modelName); //original - v7

    auto* ctorPtr = dictionaryConstructorTable(modelName); //v2312

    if (!ctorPtr) //test
    {
        FatalIOErrorInLookup
        (
            tableName,
            "FGMTable",
            modelName,
            *dictionaryConstructorTablePtr_
        ) << exit(FatalIOError);
    }


//    return cstrIter()(mesh, tablePath, tableName); //original - v7

    return autoPtr<FGMTable>(ctorPtr(mesh, tablePath, tableName)); //v2312

}

// * * * * * * * * * * * * * *  Member Functions * * * * * * * * * * * * * * //

} // End Foam namespace
